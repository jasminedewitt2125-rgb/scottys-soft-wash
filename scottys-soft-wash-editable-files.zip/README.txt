SCOTTY'S SOFT WASH — EDITABLE WEBSITE FILES

FOLDER STRUCTURE
- index.html — page content and section order
- css/styles.css — colors, spacing, typography, cards, and mobile layout
- js/script.js — menu, sliders, gallery, lightbox, FAQ, and estimate form
- assets/ — logo and all real business images

LIVE EDITING
1. Keep this entire folder together.
2. Open the folder in VS Code, Replit, or Pinegrow.
3. Open index.html and start the live preview.
4. Edit page wording in index.html.
5. Edit visual styling in css/styles.css.
6. Edit interactions in js/script.js.

MAIN COLORS
At the top of css/styles.css, edit the variables under :root, including:
--black, --panel, --blue, --red, --white, and --muted.

IMPORTANT
Do not move index.html away from the css, js, or assets folders unless you also update the file paths.
